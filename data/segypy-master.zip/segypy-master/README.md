# SegyPY : A Python module for reading/writing of SEG-Y formatted files
Copyright (C) 2005 Thomas Mejer Hansen, cultpenguin@gmail.com

Currently you can READ IBM Floats, IEEE, 1, 2 and 4 byte INTEGER formatted data, and WRITE anything but IBM Floats.

## ACKNOWLEDGEMENT ##
The Ibm2Ieee conversion routines are developed and made availabe for SegyPY by Secchi Angelo, who thanks Howard Lightstone and Anton Vredegoor for their help.


